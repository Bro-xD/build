import{d as i,E as o,e as f,n as p,j as c,h as d,i as h}from"./SCCXHowg.js";function _(r,s,...t){var n=r,e=p,a;i(()=>{e!==(e=s())&&(a&&(c(a),a=null),a=f(()=>e(n,...t)))},o),d&&(n=h)}export{_ as s};
