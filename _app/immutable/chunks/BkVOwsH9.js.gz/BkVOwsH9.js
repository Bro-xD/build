import{Q as a}from"./Bsa_4GQg.js";a();
