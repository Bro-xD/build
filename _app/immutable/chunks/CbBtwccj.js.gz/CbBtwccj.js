import{h as r,c,d as i,E as s,e as h,f as d,i as p}from"./SCCXHowg.js";function u(f,t,o){r&&c();var n=f,a,e;i(()=>{a!==(a=t())&&(e&&(d(e),e=null),a&&(e=h(()=>o(n,a))))},s),r&&(n=p)}export{u as c};
