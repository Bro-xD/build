import{h as r,k as c,l as s,E as i,m as h,p,n as m}from"./Bsa_4GQg.js";function l(t,f,o){r&&c();var e=t,a,n;s(()=>{a!==(a=f())&&(n&&(p(n),n=null),a&&(n=h(()=>o(e,a))))},i),r&&(e=m)}export{l as c};
