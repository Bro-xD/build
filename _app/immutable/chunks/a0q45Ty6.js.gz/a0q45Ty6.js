import{l as o,E as f,m as i,o as p,s as c,h,n as d}from"./Bsa_4GQg.js";function E(r,e,...t){var n=r,s=p,a;o(()=>{s!==(s=e())&&(a&&(c(a),a=null),a=i(()=>s(n,...t)))},f),h&&(n=d)}export{E as s};
