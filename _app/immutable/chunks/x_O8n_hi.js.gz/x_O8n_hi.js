import{a7 as a}from"./SCCXHowg.js";a();
