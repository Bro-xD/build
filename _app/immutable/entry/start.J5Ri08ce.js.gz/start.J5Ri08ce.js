import{a as t}from"../chunks/CtrRh7et.js";export{t as start};
