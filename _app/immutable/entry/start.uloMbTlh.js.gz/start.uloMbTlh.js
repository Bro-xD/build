import{a as t}from"../chunks/CLZ_woKs.js";export{t as start};
